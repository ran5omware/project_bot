from .script import bot, TOKEN


bot.run(TOKEN)
